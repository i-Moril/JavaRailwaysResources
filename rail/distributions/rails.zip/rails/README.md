# 轨道模型

`standard-railonly/` 是从本地 Folia 测试服复制的无路基普通钢轨包；`standard/` 和 `standard-ballastless/` 为配套合并路基配置。

这里保存可部署到 JavaRailways 轨道包目录的模型配置。配套客户端资源已合并至 `models/resourcepack/`。

- `standard/rail_model.yml`：合并沙砾路基，Custom Model Data `730001`。
- `standard-ballastless/rail_model.yml`：合并石质路基，Custom Model Data `730002`。
- 钢轨 `light_probe_offset` 为 `(0, 0.5, 0)`。
- 路基 `light_probe_offset` 为 `(0.505, 1.505, 0)`，相对于 Display 视觉原点。

资源包入口为 `models/resourcepack/assets/minecraft/items/paper.json`，模型位于 `models/resourcepack/assets/javarailways/models/rail/`。
